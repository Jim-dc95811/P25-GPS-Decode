#!/usr/bin/env python3
"""Universal Traveler Manager - set up a Universal Traveler box in one shot, from the PC.

The Universal Traveler decodes P25 GPS straight off the air (radio audio -> USB sound
card -> on-box decode) and serves a live split-screen map to any browser - no cooperating
base, no SDR, no PC. This app turns a bare GL-MT3000 into one in a single button.

A fully independent product: its own files, zero shared with the BK/Lookout managers
(a Universal Traveler box carries only Universal Traveler files).

Three tabs:
  * Set up a box  - point it at a GL-MT3000 (IP + admin password). It FIRST checks the
    box is on the kernel-6.6 firmware (OpenWrt 24.10), because that is the kernel where
    the USB sound card and the map SSD coexist on one hub. If the box is still on the old
    21.02/5.4 firmware it refuses and tells you to flash 6.6 via GL's dashboard first (a
    supported button - this app never flashes firmware itself). Then it installs
    everything over SSH: python3 + libusb + the sound-card driver, the decode engine, the
    GPS reader, the split-screen map server, the two boot services, starts them, verifies
    the map actually serves, and saves to flash.
  * Name units    - load the unit-ID -> name table from a running box, edit, save back.
  * Make QR card  - a print-ready sticker: scan it, the split-screen map opens. No typing.

The box files ship bundled beside this app (the "Universal Traveler Files" folder). Each
is streamed to the box with `cat > file`, which works on the box's dropbear SSH (no SFTP).
The box needs the internet only once, for the system packages from GL/OpenWrt's own feed.

Standard library + paramiko (SSH) + Pillow (the QR card). The .bat installs both.

Run:  double-click  Start Universal Traveler Manager.bat
"""
import os, sys, json, socket, http.client, threading, queue
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))                 # so the QR tab can import the sealed lookout_qr

VERSION       = "1.3"
MAP_PORT      = 8088
FEED_PORT     = 10110
DEFAULT_IP    = "192.168.8.1"
DEFAULT_TOKEN = "lookout"

# --- op24 firmware, for the optional scripted flash (Flash to op24 tab) --------
# The exact GL-MT3000 OpenWrt 24.10 / kernel-6.6 image we proved. The flash NEVER
# proceeds unless the bytes on the box hash to this - a corrupt image is the one
# real way to brick, so the on-box SHA-256 check is the hard gate.
FW_NAME   = "mt3000-op-4.8.3-op24_beta1-911-1108-1762535774.bin"
FW_SHA256 = "1afcd73e389a89cfb0fe05e8a828f6e755ca708aa3f300bae5d7ce32d66d4eca"
FW_BYTES  = 63407569


# --- the provisioning sequence -------------------------------------------------
# Built on the proven Lookout/Traveler provisioning engine. Two kinds of step:
#   sh(label, cmd)                        - a plain shell command
#   fetch(label, files, pre=.., post=..)  - stream files from the bundled
#       "Universal Traveler Files" folder onto the box (cat > remote).
# The kernel-6.6 check is NOT a step here - it runs first, before anything is
# touched, so a box on the wrong firmware is refused cleanly (see _run).
def sh(label, cmd, critical=False, timeout=240, onfail=None):
    return ("sh", label, cmd, critical, timeout, onfail)
def fetch(label, files, pre=None, post=None):  return ("fetch", label, files, pre, post)

# the sealed DSP decode engine (bit-exact, bolted in untouched)
_ENGINE = ["squelch.py", "decode_core.py", "frontend.py", "fsk4_demod.py",
           "framer.py", "pdu_blocks.py", "bch_nid.py", "taps_data.py"]

SETUP_STEPS = [
    sh("Updating the package list",            "opkg update", critical=True, timeout=300,
       onfail="Could not reach the package feed. The box needs the internet ONCE for setup - "
              "check its uplink (WAN cable or Wi-Fi repeater) and run this again."),
    sh("Installing Python (takes a minute)",   "which python3 >/dev/null 2>&1 && echo 'already installed' || opkg install python3",
       critical=True, timeout=600,
       onfail="python3 could not be installed from the feed (needs internet, or the op24 feed was "
              "unreachable). Fix the box's internet and run this again."),
    sh("Installing GPS support (libusb)",      "opkg list-installed | grep -q '^libusb-1.0-0 ' && echo 'already installed' || opkg install libusb-1.0-0",
       critical=True, timeout=300,
       onfail="libusb could not be installed (the box's own GPS 'you are here' needs it). "
              "Check internet and run this again."),
    sh("Installing sound-card support",        "opkg list-installed | grep -q '^kmod-usb-audio ' && echo 'already installed' || opkg install kmod-usb-audio alsa-utils",
       critical=True, timeout=300,
       onfail="The sound-card driver (kmod-usb-audio / alsa-utils) could not be installed - this is "
              "what the radio audio is captured with. Check internet and run this again."),
    fetch("Delivering the decode engine",      [("ut_bridge.py", "/root/ut_bridge.py")] +
                                               [(f, "/root/" + f) for f in _ENGINE]),
    fetch("Delivering the GPS reader",         [("gps_source.py",   "/root/gps_source.py"),
                                                ("garmin_linux.py", "/root/garmin_linux.py")]),
    fetch("Delivering the map server",         [("units_kml.py",    "/root/units_kml.py")]),
    fetch("Delivering the split-screen map",   [("map.html",        "/root/map.html"),
                                                ("leaflet.js",      "/root/leaflet.js"),
                                                ("leaflet.css",     "/root/leaflet.css")]),
    fetch("Installing the boot services",      [("openwrt/ut-bridge", "/etc/init.d/ut-bridge"),
                                                ("openwrt/units-kml", "/etc/init.d/units-kml")],
                                               post="chmod +x /etc/init.d/ut-bridge /etc/init.d/units-kml"),
    sh("Enabling them on boot",                "/etc/init.d/ut-bridge enable && /etc/init.d/units-kml enable"),
    sh("Starting the services",                "/etc/init.d/ut-bridge start && /etc/init.d/units-kml start"),
    sh("Checking they are running",            "sleep 2; ps | grep -c '[p]ython3 /root'"),
    sh("Saving everything to flash",           "sync"),   # REQUIRED - or a power-pull reverts the whole setup
]

SERVICES_EXPECTED = 2   # decode bridge + map server


def all_fetch_files():
    out = []
    for step in SETUP_STEPS:
        if step[0] == "fetch":
            out.extend(step[2])
    return out

def default_files_dir():
    return HERE / "Universal Traveler Files"

def default_fw_path():
    """Where the op24 .bin is expected: bundled beside the app first, else a copy already
    sitting in the user's Downloads. Returns a Path if found, else None (user browses)."""
    for cand in (HERE / "firmware" / FW_NAME, Path.home() / "Downloads" / FW_NAME):
        if cand.is_file():
            return cand
    return None


# ======================= Set up a box tab =======================
class SetupTab(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.q = queue.Queue(); self.running = False
        self.files_dir = tk.StringVar(value=str(default_files_dir()))

        top = tk.Frame(self, padx=10, pady=10); top.pack(fill="x")
        tk.Label(top, text="New box IP").grid(row=0, column=0, sticky="w")
        self.ip = tk.Entry(top, width=16); self.ip.insert(0, DEFAULT_IP); self.ip.grid(row=0, column=1, padx=6)
        tk.Label(top, text="Admin password").grid(row=0, column=2, sticky="w")
        self.pw = tk.Entry(top, width=16, show="*"); self.pw.grid(row=0, column=3, padx=6)
        self.btn = tk.Button(top, text="Set up this box", command=self.start,
                             bg="#1f6feb", fg="white", font=("Segoe UI", 9, "bold"))
        self.btn.grid(row=0, column=4, padx=6)

        src = tk.LabelFrame(self, text=" Universal Traveler program files ", padx=10, pady=6)
        src.pack(fill="x", padx=12, pady=(2, 4))
        tk.Entry(src, textvariable=self.files_dir, width=52).grid(row=0, column=0, sticky="w", padx=(2, 4))
        tk.Button(src, text="Change...", command=self._browse).grid(row=0, column=1, sticky="w")

        tk.Label(self, anchor="w", padx=12, fg="#555", justify="left",
                 text="The box must already be on the kernel-6.6 firmware (OpenWrt 24.10) - flash it "
                      "once via GL's dashboard; this app checks and will tell you if it isn't. The box "
                      "then needs internet once for the system packages (python3 + libusb + sound-card "
                      "driver). Everything else streams from the folder above. SSH password is not saved."
                 ).pack(fill="x")

        box = tk.Frame(self, padx=12, pady=6); box.pack(fill="both", expand=True)
        self.log = tk.Text(box, wrap="word", height=16, font=("Consolas", 9),
                           bg="#101418", fg="#d6e2ee", insertbackground="#d6e2ee")
        lsb = tk.Scrollbar(box, command=self.log.yview); self.log.configure(yscrollcommand=lsb.set)
        self.log.pack(side="left", fill="both", expand=True); lsb.pack(side="right", fill="y")
        self.log.configure(state="disabled")
        self.log.tag_config("ok", foreground="#49d17a")
        self.log.tag_config("err", foreground="#ff6b6b")
        self.log.tag_config("step", foreground="#8ab4ff")
        self.after(120, self._drain)

    def _browse(self):
        d = filedialog.askdirectory(title="Pick the Universal Traveler Files folder",
                                    initialdir=self.files_dir.get() or ".")
        if d: self.files_dir.set(d)

    def write(self, msg, tag=None): self.q.put((msg, tag))

    def _drain(self):
        try:
            while True:
                msg, tag = self.q.get_nowait()
                self.log.configure(state="normal")
                self.log.insert("end", msg + "\n", tag or ())
                self.log.see("end"); self.log.configure(state="disabled")
        except queue.Empty:
            pass
        self.after(120, self._drain)

    def start(self):
        if self.running: return
        ip = self.ip.get().strip(); pw = self.pw.get()
        if not ip or not pw:
            return self.write("Enter the box IP and its admin password first.", "err")
        files_dir = self.files_dir.get().strip()
        missing = self._missing_local_files(files_dir)
        if missing is None:
            return self.write("Universal Traveler Files folder not found: %s\nClick \"Change...\" "
                              "and pick the folder bundled with this app." % files_dir, "err")
        if missing:
            return self.write("These files are missing from %s:\n   %s\nPick the right folder."
                              % (files_dir, "\n   ".join(missing)), "err")
        self.running = True
        self.btn.config(state="disabled", text="Setting up...")
        self.log.configure(state="normal"); self.log.delete("1.0", "end"); self.log.configure(state="disabled")
        threading.Thread(target=self._run, args=(ip, pw, files_dir), daemon=True).start()

    def _missing_local_files(self, files_dir):
        base = Path(files_dir)
        if not base.is_dir(): return None
        return [bp for bp, _r in all_fetch_files() if not (base / Path(bp)).is_file()]

    def _exec(self, c, cmd, timeout=240):
        _in, out, err = c.exec_command(cmd, timeout=timeout)
        for line in iter(out.readline, ""):
            if line.strip(): self.write("   " + line.rstrip())
        rc = out.channel.recv_exit_status()
        etxt = err.read().decode("utf-8", "replace").strip()
        if etxt:
            for line in etxt.splitlines(): self.write("   " + line)
        return rc

    def _capture(self, c, cmd):
        _in, out, _e = c.exec_command(cmd, timeout=20)
        return out.read().decode("utf-8", "replace").strip()

    def _put_file(self, c, local, remote):
        """Stream a local file to the box with `cat > remote` over a plain exec channel -
        works on dropbear SSH (no SFTP subsystem)."""
        with open(local, "rb") as fh:
            data = fh.read()
        stdin, stdout, stderr = c.exec_command("cat > '%s'" % remote, timeout=120)
        stdin.write(data); stdin.flush(); stdin.channel.shutdown_write()
        rc = stdout.channel.recv_exit_status()
        etxt = stderr.read().decode("utf-8", "replace").strip()
        if etxt:
            for line in etxt.splitlines(): self.write("   " + line)
        return rc

    def _kernel_ok(self, c):
        """Refuse any box not on the kernel-6.x firmware (OpenWrt 24.10). That is the kernel
        with the xhci-mtk fix, so the USB sound card and the map SSD coexist on one hub."""
        rel = self._capture(c, "uname -r") or "?"
        glv = self._capture(c, "cat /etc/glversion 2>/dev/null") or "?"
        self.write("Box kernel %s  (GL %s)" % (rel, glv), "step")
        major = rel.split(".", 1)[0]
        if major.isdigit() and int(major) >= 6:
            self.write("Kernel 6.x confirmed - sound card + SSD can share the hub.", "ok")
            return True
        self.write("This box is on kernel %s - too old for the Universal Traveler." % rel, "err")
        self.write("It needs the OpenWrt 24.10 / kernel-6.6 firmware so the USB sound card and the "
                   "map SSD work together on one hub.", "err")
        self.write("Flash it with the \"Flash to op24\" tab in this app (or GL's dashboard), then "
                   "do GL first-boot and run this again.", "err")
        return False

    def _verify(self, ip):
        """Functional check (not just 'a process is alive'): the map page actually serves on
        :8088 and the decoded feed is listening on :10110."""
        ok_map = ok_feed = False
        try:
            c = http.client.HTTPConnection(ip, MAP_PORT, timeout=6)
            c.request("GET", "/"); r = c.getresponse(); body = r.read(4000)
            ok_map = (r.status == 200 and (b"leaflet" in body.lower() or b"traveler" in body.lower()))
        except Exception:
            ok_map = False
        try:
            s = socket.create_connection((ip, FEED_PORT), timeout=6)
            s.settimeout(7)
            data = b""
            try:
                while b"\r\n" not in data and len(data) < 400:
                    chunk = s.recv(200)
                    if not chunk: break
                    data += chunk
            except socket.timeout:
                pass
            s.close()
            ok_feed = b"$" in data          # any NMEA line (the LINK heartbeat arrives within ~5s)
        except Exception:
            ok_feed = False
        return ok_map, ok_feed

    def _run(self, ip, pw, files_dir):
        try:
            import paramiko
        except ImportError:
            self.write("The SSH library (paramiko) is not installed. Close this and run the .bat "
                       "again - it installs it. Or: pip install paramiko", "err")
            return self._done()
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            self.write("Connecting to %s ..." % ip, "step")
            c.connect(ip, username="root", password=pw, timeout=12,
                      look_for_keys=False, allow_agent=False)
            self.write("Connected.", "ok")
        except Exception as e:
            self.write("Could not log in: %s" % e, "err")
            self.write("Check the IP, that it is a GL-MT3000, and the admin password.", "err")
            return self._done()
        try:
            if not self._kernel_ok(c):            # the firmware gate - refuse early, cleanly
                return self._done()
            self.write("Files: %s\n" % files_dir, "ok")
            fetch_failed = False
            for step in SETUP_STEPS:
                kind, label = step[0], step[1]
                self.write("== %s ==" % label, "step")
                if kind == "sh":
                    _, _, cmd, critical, timeout, onfail = step
                    rc = self._exec(c, cmd, timeout=timeout)
                    if critical and rc != 0:
                        self.write("\nStopped at: %s  (exit %s)" % (label, rc), "err")
                        self.write(onfail or "This step failed; fix the box and run setup again.", "err")
                        return                       # finally: closes c + resets the button
                else:
                    _, _, files, pre, post = step
                    if pre: self._exec(c, pre)
                    for bundle_path, remote in files:
                        local = str(Path(files_dir) / Path(bundle_path))
                        rc = self._put_file(c, local, remote)
                        if rc == 0:
                            self.write("   sent %s" % remote)
                        else:
                            fetch_failed = True
                            self.write("   FAILED writing %s (exit %s)" % (remote, rc), "err")
                    if post: self._exec(c, post)
            if fetch_failed:
                self.write("\nStopped: one or more program files did not transfer (see the FAILED lines "
                           "above). Check the Universal Traveler Files folder and run setup again.", "err")
                return
            count = self._capture(c, "ps | grep -c '[p]ython3 /root'") or "0"
            self.write("\nServices running: %s (expected %d)" % (count, SERVICES_EXPECTED), "step")
            self.write("Checking the map actually serves ...", "step")
            ok_map, ok_feed = self._verify(ip)
            self.write("   map page on :%d  -> %s" % (MAP_PORT, "OK" if ok_map else "not responding"),
                       "ok" if ok_map else "err")
            self.write("   decoded feed on :%d -> %s" % (FEED_PORT, "listening" if ok_feed else "silent"),
                       "ok" if ok_feed else "err")
            if ok_map and ok_feed:
                self.write("\nDONE - this box is now a Universal Traveler.", "ok")
                self.write("Plug the sound card (radio audio), the map SSD and the Garmin into the "
                           "powered hub, then open the split-screen map at  http://%s:%d/" % (ip, MAP_PORT), "ok")
                self.write("Make a QR sticker for it on the \"Make QR card\" tab.", "ok")
            else:
                self.write("\nSetup ran but the functional check did not pass - see the lines above "
                           "and the log for a package or file error, then re-run.", "err")
        except Exception as e:
            self.write("Setup stopped: %s" % e, "err")
        finally:
            try: c.close()
            except Exception: pass
            self._done()

    def _done(self):
        self.running = False
        self.after(0, lambda: self.btn.config(state="normal", text="Set up this box"))


# ======================= Name units tab =======================
class NamesTab(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        top = tk.Frame(self, padx=10, pady=10); top.pack(fill="x")
        tk.Label(top, text="Box IP").grid(row=0, column=0, sticky="w")
        self.ip = tk.Entry(top, width=16); self.ip.insert(0, DEFAULT_IP); self.ip.grid(row=0, column=1, padx=6)
        tk.Label(top, text="Token").grid(row=0, column=2, sticky="w")
        self.token = tk.Entry(top, width=12); self.token.insert(0, DEFAULT_TOKEN); self.token.grid(row=0, column=3, padx=6)
        tk.Button(top, text="Load from box", command=self.load).grid(row=0, column=4, padx=4)

        hdr = tk.Frame(self, padx=12); hdr.pack(fill="x")
        tk.Label(hdr, text="Unit ID", width=20, anchor="w", font=("Segoe UI", 9, "bold")).grid(row=0, column=0)
        tk.Label(hdr, text="Name",    width=28, anchor="w", font=("Segoe UI", 9, "bold")).grid(row=0, column=1)

        mid = tk.Frame(self); mid.pack(fill="both", expand=True, padx=12)
        self.canvas = tk.Canvas(mid, highlightthickness=0)
        sb = tk.Scrollbar(mid, orient="vertical", command=self.canvas.yview)
        self.rows_frame = tk.Frame(self.canvas)
        self.rows_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.create_window((0, 0), window=self.rows_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=sb.set)
        self.canvas.pack(side="left", fill="both", expand=True); sb.pack(side="right", fill="y")
        self.rows = []

        bot = tk.Frame(self, padx=10, pady=8); bot.pack(fill="x")
        tk.Button(bot, text="+ Add unit", command=lambda: self.add_row("", "")).pack(side="left")
        tk.Button(bot, text="Save to box", command=self.save, bg="#228B55", fg="white",
                  font=("Segoe UI", 9, "bold")).pack(side="right")
        self.status = tk.Label(self, text="Enter the box IP and click \"Load from box\".",
                               anchor="w", fg="#555", padx=12, pady=4)
        self.status.pack(fill="x")
        self.add_row("", "")

    def add_row(self, uid, name):
        fr = tk.Frame(self.rows_frame)
        e1 = tk.Entry(fr, width=20); e1.insert(0, uid); e1.grid(row=0, column=0, padx=2, pady=2)
        e2 = tk.Entry(fr, width=28); e2.insert(0, name); e2.grid(row=0, column=1, padx=2, pady=2)
        tk.Button(fr, text="-", width=2, command=lambda: self.del_row(fr)).grid(row=0, column=2, padx=4)
        fr.pack(anchor="w"); self.rows.append((fr, e1, e2))

    def del_row(self, fr):
        self.rows = [r for r in self.rows if r[0] is not fr]; fr.destroy()

    def clear(self):
        for fr, _, _ in self.rows: fr.destroy()
        self.rows = []

    def _conn(self):
        return http.client.HTTPConnection(self.ip.get().strip(), MAP_PORT, timeout=6)

    def load(self):
        try:
            c = self._conn()
            c.request("GET", "/admin/aliases?token=" + self.token.get().strip())
            r = c.getresponse(); data = json.loads(r.read() or b"{}")
            if r.status != 200 or not data.get("ok"):
                return self.set_status("Load failed: " + str(data.get("error", r.status)), True)
            al = data.get("aliases", {}); self.clear()
            for uid, name in sorted(al.items()): self.add_row(uid, name)
            if not al: self.add_row("", "")
            self.set_status("Loaded %d name(s) from %s." % (len(al), self.ip.get().strip()))
        except Exception as e:
            self.set_status("Could not reach the box: %s" % e, True)

    def save(self):
        out = {}
        for _, e1, e2 in self.rows:
            uid = e1.get().strip()
            if uid: out[uid] = e2.get().strip()
        try:
            c = self._conn()
            c.request("POST", "/admin/aliases?token=" + self.token.get().strip(),
                      body=json.dumps(out).encode(), headers={"Content-Type": "application/json"})
            r = c.getresponse(); data = json.loads(r.read() or b"{}")
            if r.status != 200 or not data.get("ok"):
                return self.set_status("Save failed: " + str(data.get("error", r.status)), True)
            self.set_status("Saved %s name(s). The map updates within a few seconds." % data.get("count"))
        except Exception as e:
            self.set_status("Could not reach the box: %s" % e, True)

    def set_status(self, msg, err=False):
        self.status.config(text=msg, fg="#c00" if err else "#282")


# ======================= Make QR card tab =======================
class QrTab(tk.Frame):
    """Print-ready QR stickers for the box. Three kinds:
         Open the map  - scan opens the split-screen map (http://, so the phone won't force https)
         Join the Wi-Fi- scan joins the box's Wi-Fi
         Join + open   - one card, two codes: join the Wi-Fi, then open the map
    The QR encoder (lookout_qr) is the sealed, Android-tested one (exact WIFI: field order)."""
    def __init__(self, master):
        super().__init__(master)
        top = tk.Frame(self, padx=10, pady=10); top.pack(fill="x")
        tk.Label(top, text="Box IP").grid(row=0, column=0, sticky="w")
        self.ip = tk.Entry(top, width=16); self.ip.insert(0, DEFAULT_IP); self.ip.grid(row=0, column=1, padx=6)
        tk.Label(top, text="Label (optional)").grid(row=0, column=2, sticky="w")
        self.name = tk.Entry(top, width=18); self.name.grid(row=0, column=3, padx=6)
        tk.Button(top, text="Make QR card", command=self.make, bg="#1f6feb", fg="white",
                  font=("Segoe UI", 9, "bold")).grid(row=0, column=4, padx=6)

        mode = tk.LabelFrame(self, text=" What should the sticker do? ", padx=10, pady=6)
        mode.pack(fill="x", padx=12, pady=(2, 4))
        self.mode = tk.StringVar(value="map")
        for i, (val, txt) in enumerate([("map",   "Open the map"),
                                        ("wifi",  "Join the Wi-Fi"),
                                        ("combo", "Join + open (two codes)")]):
            tk.Radiobutton(mode, text=txt, variable=self.mode, value=val,
                           command=self._sync).grid(row=0, column=i, sticky="w", padx=(0, 14))

        self.wifi_fr = tk.Frame(self, padx=12, pady=2)
        tk.Label(self.wifi_fr, text="Wi-Fi name (SSID)").grid(row=0, column=0, sticky="w")
        self.ssid = tk.Entry(self.wifi_fr, width=22); self.ssid.grid(row=0, column=1, padx=6)
        tk.Label(self.wifi_fr, text="Password").grid(row=0, column=2, sticky="w")
        self.wpw = tk.Entry(self.wifi_fr, width=18); self.wpw.grid(row=0, column=3, padx=6)
        tk.Label(self.wifi_fr, text="(leave the password blank for an open network)",
                 fg="#777").grid(row=1, column=1, columnspan=3, sticky="w")

        tk.Label(self, anchor="w", padx=12, pady=6, fg="#555", justify="left",
                 text="A crew scans the sticker with a phone camera - no app, no typing. \"Open the map\" "
                      "carries the address as http:// so the phone won't force https. For Wi-Fi: if a phone "
                      "was ever on this network before, Forget it first to re-test, and answer \"stay "
                      "connected? -> Always\" (the box has no internet, so Android may drop it otherwise)."
                 ).pack(fill="x")
        self.status = tk.Label(self, text="", anchor="w", fg="#282", padx=12, pady=6, justify="left")
        self.status.pack(fill="x")
        self._sync()

    def _sync(self):
        # show the SSID/password row only for the Wi-Fi modes (pack/pack_forget, never reparent)
        if self.mode.get() in ("wifi", "combo"):
            self.wifi_fr.pack(fill="x", before=self.status)
        else:
            self.wifi_fr.pack_forget()

    def make(self):
        try:
            import lookout_qr                      # sealed QR encoder (bolted in)
        except Exception as e:
            return self._err("QR library not available (%s). Run the .bat so Pillow installs." % e)
        ip = self.ip.get().strip()
        if not ip:
            return self._err("Enter the box IP first.")
        m = self.mode.get()
        ssid = self.ssid.get().strip(); wpw = self.wpw.get()
        if m in ("wifi", "combo") and not ssid:
            return self._err("Enter the Wi-Fi name (SSID) for a Wi-Fi sticker.")
        url = lookout_qr.normalize("http://%s:%d/" % (ip, MAP_PORT))
        try:
            if m == "map":
                img, _ver = lookout_qr.make_card(url, box_name=self.name.get().strip())
                kind, opens = "Map", "opens the map at " + url
            elif m == "wifi":
                wifi_s = lookout_qr.wifi_payload(ssid, wpw, open_net=(wpw == ""))
                img, _ver = lookout_qr.make_wifi_card(wifi_s, ssid)
                kind, opens = "WiFi", "joins Wi-Fi \"" + ssid + "\""
            else:
                wifi_s = lookout_qr.wifi_payload(ssid, wpw, open_net=(wpw == ""))
                img, _ver = lookout_qr.make_combo_card(wifi_s, url, ssid)
                kind, opens = "Join+Open", "joins Wi-Fi \"" + ssid + "\", then opens the map"
            out_dir = Path.home() / "Downloads"
            out_dir.mkdir(parents=True, exist_ok=True)
            tag = (self.name.get().strip() or ip).replace(os.sep, "_").replace(" ", "_")
            path = out_dir / ("Universal_Traveler_QR_%s_%s.png" % (kind, tag))
            img.save(str(path))
            self.status.config(fg="#282",
                               text="Saved: %s\nScan %s.\nPrint it and stick it on the box." % (path, opens))
        except Exception as e:
            self._err("Could not make the card: %s" % e)

    def _err(self, msg):
        self.status.config(text=msg, fg="#c00")


# ======================= Flash to op24 tab =======================
class FlashTab(tk.Frame):
    """Scripted firmware flash to OpenWrt 24.10 / kernel 6.6. Standalone phase: it streams
    the proven .bin to the box's RAM (/tmp), SHA-256 verifies it ON THE BOX, then runs
    `sysupgrade -n` (no-keep-settings, mandatory op21->op24) and waits for the box to return.
    A -n flash resets the box to factory, so afterward you do GL first-boot (set a password)
    and then 'Set up a box'. If anything fails, the box is a $100 widget with a reset button:
    hold reset ~10s for GL's recovery page and re-flash."""
    def __init__(self, master):
        super().__init__(master)
        self.q = queue.Queue(); self.running = False
        dflt = default_fw_path()
        self.fw = tk.StringVar(value=str(dflt) if dflt else "")

        top = tk.Frame(self, padx=10, pady=10); top.pack(fill="x")
        tk.Label(top, text="Box IP").grid(row=0, column=0, sticky="w")
        self.ip = tk.Entry(top, width=16); self.ip.insert(0, DEFAULT_IP); self.ip.grid(row=0, column=1, padx=6)
        tk.Label(top, text="Admin password").grid(row=0, column=2, sticky="w")
        self.pw = tk.Entry(top, width=16, show="*"); self.pw.grid(row=0, column=3, padx=6)
        self.btn = tk.Button(top, text="Flash to op24", command=self.start,
                             bg="#b5651d", fg="white", font=("Segoe UI", 9, "bold"))
        self.btn.grid(row=0, column=4, padx=6)

        src = tk.LabelFrame(self, text=" op24 firmware image (.bin) ", padx=10, pady=6)
        src.pack(fill="x", padx=12, pady=(2, 4))
        tk.Entry(src, textvariable=self.fw, width=52).grid(row=0, column=0, sticky="w", padx=(2, 4))
        tk.Button(src, text="Change...", command=self._browse).grid(row=0, column=1, sticky="w")

        tk.Label(self, anchor="w", padx=12, fg="#555", justify="left",
                 text="Flashes the box to OpenWrt 24.10 / kernel 6.6 - the kernel where the sound card and "
                      "the map SSD share one hub. Only needed on a box still on the old (5.4) firmware.\n"
                      "This ERASES the box (resets to factory). Keep it on stable power and don't touch it "
                      "for ~3-4 minutes. If a flash ever fails, hold the reset button ~10s for GL's recovery "
                      "page and flash again.\nAfter it finishes: open the box, do GL first-boot (set an admin "
                      "password), then use \"Set up a box\"."
                 ).pack(fill="x")

        box = tk.Frame(self, padx=12, pady=6); box.pack(fill="both", expand=True)
        self.log = tk.Text(box, wrap="word", height=14, font=("Consolas", 9),
                           bg="#101418", fg="#d6e2ee", insertbackground="#d6e2ee")
        lsb = tk.Scrollbar(box, command=self.log.yview); self.log.configure(yscrollcommand=lsb.set)
        self.log.pack(side="left", fill="both", expand=True); lsb.pack(side="right", fill="y")
        self.log.configure(state="disabled")
        self.log.tag_config("ok", foreground="#49d17a")
        self.log.tag_config("err", foreground="#ff6b6b")
        self.log.tag_config("step", foreground="#8ab4ff")
        self.after(120, self._drain)

    def _browse(self):
        f = filedialog.askopenfilename(title="Pick the op24 firmware .bin",
                                       filetypes=[("Firmware image", "*.bin"), ("All files", "*.*")],
                                       initialdir=str(Path(self.fw.get()).parent) if self.fw.get() else str(Path.home()))
        if f: self.fw.set(f)

    def write(self, msg, tag=None): self.q.put((msg, tag))

    def _drain(self):
        try:
            while True:
                msg, tag = self.q.get_nowait()
                self.log.configure(state="normal")
                self.log.insert("end", msg + "\n", tag or ())
                self.log.see("end"); self.log.configure(state="disabled")
        except queue.Empty:
            pass
        self.after(120, self._drain)

    def start(self):
        if self.running: return
        ip = self.ip.get().strip(); pw = self.pw.get(); fw = self.fw.get().strip()
        if not ip or not pw:
            return self.write("Enter the box IP and its admin password first.", "err")
        if not fw or not Path(fw).is_file():
            return self.write("Pick the op24 firmware .bin (Change...). Expected: %s" % FW_NAME, "err")
        import hashlib
        h = hashlib.sha256(Path(fw).read_bytes()).hexdigest()
        if h != FW_SHA256:
            return self.write("That .bin does not match the known-good op24 image (SHA-256 mismatch) - "
                              "refusing to flash it. Pick the right file.\n  got:      %s\n  expected: %s"
                              % (h, FW_SHA256), "err")
        if not messagebox.askyesno("Flash to op24",
                "This ERASES the box and flashes OpenWrt 24.10 / kernel 6.6.\n\n"
                "Keep it on stable power and don't touch it for ~3-4 minutes.\n\nContinue?"):
            return
        self.running = True
        self.btn.config(state="disabled", text="Flashing...")
        self.log.configure(state="normal"); self.log.delete("1.0", "end"); self.log.configure(state="disabled")
        threading.Thread(target=self._run, args=(ip, pw, fw), daemon=True).start()

    def _capture(self, c, cmd):
        _in, out, _e = c.exec_command(cmd, timeout=30)
        return out.read().decode("utf-8", "replace").strip()

    def _put_bin(self, c, local, remote):
        """Stream the firmware to the box in chunks (cat >), with progress. dropbear-safe."""
        total = os.path.getsize(local); sent = 0; last = 0
        stdin, stdout, stderr = c.exec_command("cat > '%s'" % remote, timeout=900)
        with open(local, "rb") as fh:
            while True:
                b = fh.read(262144)
                if not b: break
                stdin.write(b); sent += len(b)
                if sent - last >= 8 * (1 << 20):
                    last = sent
                    self.write("   uploaded %d / %d MB" % (sent >> 20, total >> 20))
        stdin.flush(); stdin.channel.shutdown_write()
        return stdout.channel.recv_exit_status()

    def _run(self, ip, pw, fw):
        import time
        try:
            import paramiko
        except ImportError:
            self.write("The SSH library (paramiko) is not installed. Close this and run the .bat "
                       "again - it installs it.", "err")
            return self._done()
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            self.write("Connecting to %s ..." % ip, "step")
            c.connect(ip, username="root", password=pw, timeout=12, look_for_keys=False, allow_agent=False)
            self.write("Connected.", "ok")
        except Exception as e:
            self.write("Could not log in: %s" % e, "err")
            self.write("Check the IP, that it is the box, and the admin password. After a reset/flash the "
                       "box's SSH identity changes - that's fine, this app auto-accepts it.", "err")
            return self._done()
        try:
            rel = self._capture(c, "uname -r") or "?"
            self.write("Box kernel %s" % rel, "step")
            if rel.split(".", 1)[0].isdigit() and int(rel.split(".", 1)[0]) >= 6:
                self.write("Already on kernel 6.x (op24) - no flash needed. Go to \"Set up a box\".", "ok")
                return self._done()
            remote = "/tmp/sysupgrade.bin"
            self.write("== Uploading the op24 image to the box's RAM (~%d MB) ==" % (FW_BYTES >> 20), "step")
            rc = self._put_bin(c, fw, remote)
            if rc != 0:
                self.write("Upload failed (exit %s)." % rc, "err"); return self._done()
            self.write("== Verifying the image on the box (SHA-256) ==", "step")
            got = (self._capture(c, "sha256sum '%s' 2>/dev/null" % remote).split() or ["?"])[0]
            if got != FW_SHA256:
                self.write("On-box hash does NOT match - the upload is corrupt. NOT flashing.\n  got:      %s\n"
                           "  expected: %s" % (got, FW_SHA256), "err")
                self._capture(c, "rm -f '%s'" % remote)
                return self._done()
            self.write("Image verified byte-for-byte. Flashing now.", "ok")
            self.write("== Flashing (the box reboots; SSH will drop - expected) ==", "step")
            sysout = []
            try:
                _in, out, _e = c.exec_command("sysupgrade -n '%s' 2>&1" % remote, timeout=30)
                try:
                    for line in iter(out.readline, ""):
                        if line.strip():
                            sysout.append(line.rstrip()); self.write("   " + line.rstrip())
                except Exception:
                    pass
            except Exception:
                pass            # the connection dies as the box goes down - that's the flash starting
            try: c.close()
            except Exception: pass
            self.write("Waiting for the box to come back (up to 4 min) ...", "step")
            time.sleep(25)      # let it actually go down before we start polling
            back = False; deadline = time.time() + 240
            while time.time() < deadline:
                try:
                    s = socket.create_connection((ip, 80), timeout=4); s.close(); back = True; break
                except Exception:
                    time.sleep(5)
            if not back:
                self.write("\nThe box didn't answer within 4 minutes. Give it another minute and open "
                           "http://%s . If it's dark, hold reset ~10s for GL's recovery page and re-flash." % ip, "err")
                return
            # The box is reachable again - but did it ACTUALLY flash? A `sysupgrade -n` flash wipes the
            # admin password, so if the OLD password still logs in, the flash did NOT take (it refused
            # the image, e.g. a cross-version metadata check). Don't claim success in that case.
            if self._pw_still_works(ip, pw):
                self.write("\nThe box is up but STILL accepts the old password - so it did NOT flash "
                           "(sysupgrade refused the image; the box is still on its old firmware).", "err")
                if sysout:
                    self.write("sysupgrade said:", "err")
                    for ln in sysout[-8:]: self.write("   " + ln, "err")
                self.write("Flash it via GL's dashboard instead (Settings -> Upgrade -> the 24.10 / op24 "
                           "image, keep-settings OFF), then do first-boot and use \"Set up a box\".", "err")
                return
            self.write("\nFLASHED - the box is back on factory op24 (the old password no longer works, "
                       "which confirms the flash took).", "ok")
            self.write("Next: open  http://%s  , do GL first-boot (set an admin password), then use "
                       "\"Set up a box\" (it confirms kernel 6.6 and installs everything)." % ip, "ok")
        except Exception as e:
            self.write("Flash stopped: %s" % e, "err")
        finally:
            try: c.close()
            except Exception: pass
            self._done()

    def _pw_still_works(self, ip, pw):
        """True if the OLD admin password still logs in - which means the box did NOT reset,
        i.e. sysupgrade did not actually flash (a -n flash wipes the password)."""
        try:
            import paramiko
            t = paramiko.SSHClient(); t.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            t.connect(ip, username="root", password=pw, timeout=8,
                      look_for_keys=False, allow_agent=False)
            t.close(); return True
        except Exception:
            return False

    def _done(self):
        self.running = False
        self.after(0, lambda: self.btn.config(state="normal", text="Flash to op24"))


if __name__ == "__main__":
    root = tk.Tk()
    root.title("Universal Traveler Manager v" + VERSION)
    root.geometry("640x640")
    nb = ttk.Notebook(root)
    nb.add(FlashTab(nb), text="  Flash to op24  ")
    nb.add(SetupTab(nb), text="  Set up a box  ")
    nb.add(NamesTab(nb), text="  Name units  ")
    nb.add(QrTab(nb),    text="  Make QR card  ")
    nb.pack(fill="both", expand=True)
    root.mainloop()
