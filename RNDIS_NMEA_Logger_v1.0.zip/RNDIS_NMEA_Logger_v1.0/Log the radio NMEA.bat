@echo off
cd /d "%~dp0"
set "PYEXE=py -3"
where py >nul 2>nul || set "PYEXE=python"
echo Starting the RNDIS NMEA logger...
%PYEXE% "System Files\rndis_nmea_logger.py"
pause
